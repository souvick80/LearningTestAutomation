package com.test.zerobank;

import static org.testng.Assert.assertEquals;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.support.ui.Select;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

public class AutZeroBank {

	WebDriver driver;
	String browser= "chrome";
	String url = "http://zero.webappsecurity.com/";
	WebElement signIn_btn;
	WebElement LogIn_btn;

	@BeforeMethod(alwaysRun = true)
	public void setUp() {
		
		if(browser == "chrome") {
			System.setProperty("webdriver.chrome.driver","Browser Driver\\chromedriver.exe");
			driver = new ChromeDriver();
		}
		else if (browser == "IE") {
			System.setProperty("webdriver.ie.driver","Browser Driver\\IEDriverServer.exe");
			driver = new InternetExplorerDriver();	
		}
		else if (browser == "firefox") {
			System.setProperty("webdriver.gecko.driver","Browser Driver\\geckodriver.exe");
			driver = new FirefoxDriver();
		}
		else {
			System.out.println("Please enter a valid browser name: ");
		}
		driver.manage().window().maximize();		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);




	}
	
	@Test(groups = {"Smoke"})
	public void loginTest() {
		driver.get(url);
		assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
		signIn_btn = driver.findElement(By.id("signin_button"));
		signIn_btn.click();
		driver.findElement(By.name("user_login")).sendKeys("username");
		driver.findElement(By.id("user_password")).sendKeys("password");
		WebElement rememberMeCheckBx = driver.findElement(By.id("user_password"));

		if(rememberMeCheckBx.isDisplayed()) {
			if(rememberMeCheckBx.isEnabled()){
				if(!rememberMeCheckBx.isSelected()) {
					rememberMeCheckBx.click();
				}
			}
		}
		LogIn_btn = driver.findElement(By.name("submit"));
		LogIn_btn.click();
		WebElement details_btn =  driver.findElement(By.id("details-button"));
		if(details_btn.isDisplayed()) {
			driver.findElement(By.id("details-button")).click();
			driver.findElement(By.id("proceed-link")).click();
		}
		
		assertEquals(driver.getTitle(), "Zero - Account Summary");

	}

	// Negative TC 1
	@Test(groups = {"Regression"})
	public void loginTest_2() {
		driver.get(url);
		signIn_btn = driver.findElement(By.id("signin_button"));
		signIn_btn.click();
		LogIn_btn = driver.findElement(By.name("submit"));
		LogIn_btn.click();
		String LogInErrorMessage = driver.findElement(By.xpath("//form[@id='login_form']/div")).getText();
		try {
			assertEquals(LogInErrorMessage, "Login and/or password are wrong.");
		} catch (AssertionError e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	// Negative TC 2
	@Test(dependsOnMethods = {"loginTest"}, groups = {"Regression"})
	public void purchaseForeignCurrence() {
		loginTest();
		driver.findElement(By.id("pay_bills_tab")).click();
		assertEquals(driver.getTitle(), "Zero - Pay Bills");
		driver.findElement(By.xpath("//a[contains(text(), 'Purchase Foreign Currency')]")).click();
		String header = driver.findElement(By.xpath("//div[@id='ui-tabs-3']/h2")).getText();
		assertEquals(header, "Purchase foreign currency cash");
		driver.findElement(By.id("purchase_cash")).click();
		
		try {
			assertEquals(driver.switchTo().alert().getText(), "Please, ensure that you have "
					+ "filled all the required fields with valid values.");
		} catch (AssertionError e) {
			e.printStackTrace();
		}
		
		driver.switchTo().alert().accept();
		
		
	}
	
	@Test(groups = {"Smoke"})
	public void fundTransfer() {
		loginTest();
		driver.findElement(By.xpath("//a[contains(text(), 'Transfer Funds')]")).click();
		assertEquals(driver.getTitle(), "Zero - Transfer Funds");
		WebElement fromAccount =  driver.findElement(By.id("tf_fromAccountId"));
		Select fromAccount_drpdwn = new Select(fromAccount);
		fromAccount_drpdwn.selectByValue("2");
		WebElement toAccount =  driver.findElement(By.id("tf_toAccountId"));
		Select toAccount_drpdwn = new Select(toAccount);
		toAccount_drpdwn.selectByValue("3");
		driver.findElement(By.id("tf_amount")).sendKeys("2322");
		driver.findElement(By.id("tf_description")).sendKeys("Fund transfer");
		driver.findElement(By.id("btn_submit")).click();
		driver.findElement(By.id("btn_submit")).click();
		assertEquals(driver.findElement(By.xpath("//div[contains(@class, 'alert-success')]")).getText(), "You successfully"
				+ " submitted your transaction.");
		
		
		
	}
	
	// Negative TC 3
	@Test(groups = {"Regression"})
	public void fundTransfer_2() {
		loginTest();
		driver.findElement(By.xpath("//a[contains(text(), 'Transfer Funds')]")).click();
		String fundTransferPageTitle = driver.getTitle();
		assertEquals(fundTransferPageTitle, "Zero - Transfer Funds");
		driver.findElement(By.id("tf_description")).sendKeys("Fund transfer");
		driver.findElement(By.id("btn_submit")).click();
		assertEquals(driver.getTitle(), fundTransferPageTitle);
		
		
	}
	
	// Negative TC 4
	@Test(groups = {"Regression"})
	public void purchaseForeignCurrenc_2() {
		loginTest();
		driver.findElement(By.id("pay_bills_tab")).click();
		assertEquals(driver.getTitle(), "Zero - Pay Bills");
		driver.findElement(By.xpath("//a[contains(text(), 'Purchase Foreign Currency')]")).click();
		String header = driver.findElement(By.xpath("//div[@id='ui-tabs-3']/h2")).getText();
		assertEquals(header, "Purchase foreign currency cash");
		
		driver.findElement(By.id("pc_amount")).sendKeys("100");
		
		
		driver.findElement(By.id("purchase_cash")).click();
		
		try {
			assertEquals(driver.switchTo().alert().getText(), "Please, ensure that you have "
					+ "filled all the required fields with valid values.");
		} catch (AssertionError e) {
			e.printStackTrace();
		}
		
		driver.switchTo().alert().accept();
		
	}
	
	
	// Negative TC 5
	@Test(groups = {"Regression"})
	public void purchaseForeignCurrence_3(){
		loginTest();
		driver.findElement(By.id("pay_bills_tab")).click();
		assertEquals(driver.getTitle(), "Zero - Pay Bills");
		driver.findElement(By.xpath("//a[contains(text(), 'Purchase Foreign Currency')]")).click();
		String header = driver.findElement(By.xpath("//div[@id='ui-tabs-3']/h2")).getText();
		assertEquals(header, "Purchase foreign currency cash");
		Select currency = new Select(driver.findElement(By.id("pc_currency")));
		currency.selectByIndex(3);
		driver.findElement(By.id("pc_amount")).sendKeys("100");
		driver.findElement(By.id("purchase_cash")).click();
		try {
			assertEquals(driver.switchTo().alert().getText(), "Please, ensure that you have "
					+ "filled all the required fields with valid values.");
		} catch (AssertionError e) {
			e.printStackTrace();
		}
		
		driver.switchTo().alert().accept();
	}
	

	@AfterMethod(alwaysRun = true)
	public void tearDown() {
		driver.close();
		driver.quit();
	}

}
