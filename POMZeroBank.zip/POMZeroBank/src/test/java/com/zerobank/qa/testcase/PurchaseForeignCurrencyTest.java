package com.zerobank.qa.testcase;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.zerobank.qa.base.Base;
import com.zerobank.qa.pages.AccountSummaryPage;
import com.zerobank.qa.pages.HomePage;
import com.zerobank.qa.pages.LoginPage;
import com.zerobank.qa.pages.PayBillsPage;
import com.zerobank.qa.pages.PurchaseForeignCurrencyPage;

public class PurchaseForeignCurrencyTest extends Base {
	
	LoginPage loginPage;
	HomePage homePage;
	AccountSummaryPage accountSummaryPage;
	PayBillsPage payBillsPage;
	PurchaseForeignCurrencyPage purchaseForeignCurrencyPage;
	
	
	
	public PurchaseForeignCurrencyTest() {
		super();
	}

	@BeforeMethod (alwaysRun = true)
	public void beforeMethod() {
		initialization();
		loginPage = new LoginPage();
		homePage = new HomePage();
		accountSummaryPage = new AccountSummaryPage();
		
	}
	
	@AfterMethod (alwaysRun = true)
	public void afterMethod() throws IOException {
		driver.close();
		driver.quit();
	}
	
	@Test
	public void validatePurchaseForeignCurrencyPage() {
		homePage.clickOnSignInButton();
		loginPage.login();
		payBillsPage = accountSummaryPage.clickOnPayBillsTab();
		purchaseForeignCurrencyPage = payBillsPage.clickOnPurchaseForeignCurrencyTab();
		purchaseForeignCurrencyPage.assertPurchaseForeignCurrencyPageHeader();
	}
	
	// 1.
	//  Negative Scenario: Purchase foreign currency cash with blank data
	@Test (groups = {"Regression"})
	public void verifyPurchaseForeignCurrencyWithBlankData() {
		homePage.clickOnSignInButton();
		loginPage.login();
		payBillsPage = accountSummaryPage.clickOnPayBillsTab();
		purchaseForeignCurrencyPage = payBillsPage.clickOnPurchaseForeignCurrencyTab();
		purchaseForeignCurrencyPage.clickOnPurchaseButton();
		String alertMessage = driver.switchTo().alert().getText();
		System.out.println("Alert message is: "+ alertMessage);
		driver.switchTo().alert().accept();
		System.out.println("Alert Accepted!");
	}
	
	// 2.
	//  Negative Scenario: click on purchase with only Currency data.
	@Test (groups = {"Regression"})
	public void verifyPurchaseForeignCurrencyWithCurrency() {
		homePage.clickOnSignInButton();
		loginPage.login();
		payBillsPage = accountSummaryPage.clickOnPayBillsTab();
		purchaseForeignCurrencyPage = payBillsPage.clickOnPurchaseForeignCurrencyTab();
		purchaseForeignCurrencyPage.enterCurrency();
		purchaseForeignCurrencyPage.clickOnPurchaseButton();
		String alertMessage = driver.switchTo().alert().getText();
		System.out.println("Alert message is: "+ alertMessage);
		driver.switchTo().alert().accept();
		System.out.println("Alert Accepted!");
		
		
	}
	
	// 3.
	//  Negative Scenario: click on purchase with only Amount data.
	@Test (groups = {"Regression"})
	public void verifyPurchaseForeignCurrencyWithAmmount() {
		homePage.clickOnSignInButton();
		loginPage.login();
		payBillsPage = accountSummaryPage.clickOnPayBillsTab();
		purchaseForeignCurrencyPage = payBillsPage.clickOnPurchaseForeignCurrencyTab();
		purchaseForeignCurrencyPage.enterAmmount("300");
		purchaseForeignCurrencyPage.clickOnPurchaseButton();
		String alertMessage = driver.switchTo().alert().getText();
		System.out.println("Alert message is: "+ alertMessage);
		driver.switchTo().alert().accept();
		System.out.println("Alert Accepted!");
	}
}
