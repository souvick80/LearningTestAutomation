package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class TransferMoneyConfirmationPage extends Base{
	
	@FindBy(xpath = "//div[contains(text(),'You successfully submitted')]") WebElement successMessage;

	public TransferMoneyConfirmationPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void verifySuccessMessage() {
		assertEquals(successMessage.getText(), "You successfully submitted your transaction.");
		
	}
	

}
