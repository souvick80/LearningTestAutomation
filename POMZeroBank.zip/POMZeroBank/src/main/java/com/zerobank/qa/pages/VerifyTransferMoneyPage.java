package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class VerifyTransferMoneyPage extends Base{
	
	@FindBy(xpath = "//h2[contains(text(),'Transfer Money & Make Payments - Verify')]") WebElement header;
	@FindBy(id = "btn_submit") WebElement submitButton;
	@FindBy(xpath = "//div[contains(text(),'You successfully submitted')]") WebElement successMessage;
	
	public VerifyTransferMoneyPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertVerifyTransferMoneypageHeader() {
		assertEquals(header.getText(), "Transfer Money & Make Payments - Verify");
	}
	
	public TransferMoneyConfirmationPage clickOnSubmit() {
		submitButton.click();
		return new TransferMoneyConfirmationPage();
		
	}
	
	
}