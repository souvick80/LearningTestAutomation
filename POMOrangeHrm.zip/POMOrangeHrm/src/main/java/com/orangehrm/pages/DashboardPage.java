package com.orangehrm.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.orangehrm.base.Base;

public class DashboardPage extends Base{
	
	//Creating object of an Actions class
		Actions action;
	
	@FindBy(xpath = "//b[contains(text(),'Recruitment')]") WebElement recruitmentMenu;
	@FindBy(xpath = "//a[@id='menu_recruitment_viewCandidates']") WebElement candidateSubMenu;

	
	public DashboardPage() {
		PageFactory.initElements(driver, this);
		action = new Actions(driver);
		
	}

	public void assertDashboardPageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM");
	}
	
	public ViewCandidatesPage clickOnCandidateSubMenu() {
	action.moveToElement(recruitmentMenu).moveToElement(candidateSubMenu).click().build().perform();
	return new ViewCandidatesPage();
		

	}
	

}
