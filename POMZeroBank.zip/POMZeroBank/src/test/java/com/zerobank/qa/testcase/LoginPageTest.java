package com.zerobank.qa.testcase;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.zerobank.qa.base.Base;
import com.zerobank.qa.pages.AccountSummaryPage;
import com.zerobank.qa.pages.HomePage;
import com.zerobank.qa.pages.LoginPage;

public class LoginPageTest extends Base {
	
	LoginPage loginPage;
	HomePage homePage;
	AccountSummaryPage accountSummaryPage;
	
	public LoginPageTest() {
		super();
	}
	
	@BeforeMethod (alwaysRun = true)
	public void beforeMethod() {
		initialization();
		loginPage = new LoginPage();
		homePage = new HomePage();
		accountSummaryPage = new AccountSummaryPage();
	}
	
	@AfterMethod (alwaysRun = true)
	public void afterMethod() throws IOException {
		driver.close();
		driver.quit();
	}
	
	@Test
	public void validateLoginPage() {
		homePage.clickOnSignInButton();
		loginPage.assertLoginPageTitle();
		
	}
	
	// Positive Scenario: Login
	@Test (groups = {"Smoke"})
	public void verifyLogin() {
		homePage.clickOnSignInButton();
		accountSummaryPage = loginPage.login();
		accountSummaryPage.assertAccountSummaryPagTitle();
	}
	
	// 2.
	// Negative Scenario: Login with blank data
	@Test (groups = {"Regression"})
	public void verifyLoginWithBankData() {
		homePage.clickOnSignInButton();
		loginPage.clickOnLoginButton();
		loginPage.assertInvalidLoginErrorMessage();
		
	}
	
	


}
