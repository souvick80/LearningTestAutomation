package com.orangehrm.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.orangehrm.base.Base;

public class LoginPage extends Base{
	
	@FindBy(id = "txtUsername") WebElement usernameTxtBox;
	@FindBy(id = "txtPassword") WebElement passwordTxtBox;
	@FindBy(id = "btnLogin") WebElement loginButton;
	
	public LoginPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertLoginPageTitle() {
		assertEquals(driver.getTitle(), "OrangeHRM");
	}
	
	public DashboardPage login() {
		usernameTxtBox.sendKeys(prop.getProperty("username"));
		passwordTxtBox.sendKeys(prop.getProperty("password"));
		loginButton.click();
		return new DashboardPage();

	}

}
