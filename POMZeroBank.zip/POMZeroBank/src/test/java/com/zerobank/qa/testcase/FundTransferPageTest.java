package com.zerobank.qa.testcase;

import java.io.IOException;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.zerobank.qa.base.Base;
import com.zerobank.qa.pages.AccountSummaryPage;
import com.zerobank.qa.pages.FundTransferPage;
import com.zerobank.qa.pages.HomePage;
import com.zerobank.qa.pages.LoginPage;
import com.zerobank.qa.pages.TransferMoneyConfirmationPage;
import com.zerobank.qa.pages.VerifyTransferMoneyPage;

public class FundTransferPageTest extends Base {
	
	LoginPage loginPage;
	HomePage homePage;
	AccountSummaryPage accountSummaryPage;
	FundTransferPage fundTransferPage;
	VerifyTransferMoneyPage verifyTransferMoneyPage;
	TransferMoneyConfirmationPage transferMoneyConfirmationPage;
	
	
	public FundTransferPageTest() {
		super();
	}
	
	@BeforeMethod (alwaysRun = true)
	public void beforeMethod() {
		initialization();
		loginPage = new LoginPage();
		homePage = new HomePage();
		accountSummaryPage = new AccountSummaryPage();
		fundTransferPage = new FundTransferPage();
		
	}
	
	@AfterMethod (alwaysRun = true)
	public void afterMethod() throws IOException {
		driver.close();
		driver.quit();
	}
	
	@Test
	private void validateTransferMoneyPage() {
		homePage.clickOnSignInButton();
		loginPage.login();
		accountSummaryPage.clickOnFundTransfer();
		fundTransferPage.assertFundTransferPageTitle();
	}
	
	// Positive Scenario: Fund Transfer
	@Test (groups = {"Smoke"})
	private void transferMoneyAndMakePaymentTest() {
		homePage.clickOnSignInButton();
		loginPage.login();
		fundTransferPage = accountSummaryPage.clickOnFundTransfer();
		fundTransferPage.typeIntransferMoneypage("300", "Test comment");
		verifyTransferMoneyPage = fundTransferPage.clickOnContinue();
		verifyTransferMoneyPage.assertVerifyTransferMoneypageHeader();
		transferMoneyConfirmationPage = verifyTransferMoneyPage.clickOnSubmit();
		transferMoneyConfirmationPage.verifySuccessMessage();
		
	}
	
	// 5.
	// Negative Scenario: Fund Transfer with Blank data
	@Test(groups = {"Regression"})
	public void fundTransferWithBlankData() {
		homePage.clickOnSignInButton();
		loginPage.login();
		accountSummaryPage.clickOnFundTransfer();
		fundTransferPage.clickOnContinue();
		
	}

}
