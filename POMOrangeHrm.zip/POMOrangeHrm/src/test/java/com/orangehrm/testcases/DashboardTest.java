package com.orangehrm.testcases;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.orangehrm.base.Base;
import com.orangehrm.pages.DashboardPage;
import com.orangehrm.pages.LoginPage;
import com.orangehrm.pages.ViewCandidatesPage;

public class DashboardTest extends Base{
	
	LoginPage loginPage;
	DashboardPage dashboardpage;
	ViewCandidatesPage viewCandidatesPage;
	
	public DashboardTest() {
		super();
	}
	
	@BeforeMethod(alwaysRun = true)
	public void beforeMethod() {
		initialization();
		loginPage = new LoginPage();
		dashboardpage = new DashboardPage();
		viewCandidatesPage = new ViewCandidatesPage();
		
	}
	
	@AfterMethod(alwaysRun = true)
	public void afterMethod() {
		driver.close();
		driver.quit();
	}

	@Test
	public void validateDashboardPage() {
		dashboardpage = loginPage.login();
		dashboardpage.assertDashboardPageTitle();
		
	}
	
	@Test
	public void clickOnCandidateSubMenuTest() {
		loginPage.login();
		viewCandidatesPage = dashboardpage.clickOnCandidateSubMenu();
		
		
	}
}
