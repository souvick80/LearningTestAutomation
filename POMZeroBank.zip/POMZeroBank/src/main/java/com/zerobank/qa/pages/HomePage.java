package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

import com.zerobank.qa.base.Base;

public class HomePage extends Base {
	
	// OR:
		@FindBy(id="signin_button") WebElement signInButton;
		
		// Initializing the contractor:
		public HomePage() {
			PageFactory.initElements(driver, this);
		}

		// Actions:
		public void assertHomePageTitle() {
			assertEquals(driver.getTitle(), "Zero - Personal Banking - Loans - Credit Cards");
		}
		
		public LoginPage clickOnSignInButton() {
			signInButton.click();
			return new LoginPage();
		}
			
}
