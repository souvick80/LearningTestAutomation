package com.zerobank.qa.pages;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

import com.zerobank.qa.base.Base;

public class FundTransferPage extends Base {
	
	@FindBy(id = "tf_fromAccountId") WebElement fromAccountDrpDwn;
	@FindBy(id = "tf_toAccountId") WebElement toAccountDrpDwn;
	@FindBy(id = "tf_amount") WebElement ammountTextBox;
	@FindBy(id = "tf_description") WebElement descriptionTextBox;
	@FindBy(id = "btn_submit") WebElement continueButton;
	
	
	
	public FundTransferPage() {
		PageFactory.initElements(driver, this);
	}
	
	public void assertFundTransferPageTitle() {
		assertEquals(driver.getTitle(), "Zero - Transfer Funds");
	}
	
	public void typeIntransferMoneypage(String ammount, String description) {

		Select fromAccount = new Select(fromAccountDrpDwn);
		fromAccount.selectByIndex(2);
		Select toAcccount = new Select(toAccountDrpDwn);
		toAcccount.selectByValue("3");
		ammountTextBox.sendKeys(ammount);
		descriptionTextBox.sendKeys(description);
		
	}
	
	public VerifyTransferMoneyPage clickOnContinue() {
		continueButton.click();
		assertEquals(driver.getTitle(), "Zero - Transfer Funds");
		return new VerifyTransferMoneyPage();
	}
	

}
