package com.zerobank.qa.testcase;

import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;

import com.zerobank.qa.base.Base;
import com.zerobank.qa.pages.HomePage;
import com.zerobank.qa.pages.LoginPage;

public class HomePageTest extends Base {
	HomePage homePage;
	LoginPage loginPage;
	
	public HomePageTest() {
		super();
	}
	
	@BeforeMethod (alwaysRun = true)
	public void setup() {
		initialization();
		homePage = new HomePage();

	}
	
	@AfterMethod (alwaysRun = true)
	public void tearDown() {
		driver.close();
		driver.quit();
	}
	
	@Test
	public void validateHomePage() {
		homePage.assertHomePageTitle();	
	}
	
	@Test
	public void ClickOnSignIn() {
		loginPage = homePage.clickOnSignInButton();
		loginPage.assertLoginPageTitle();
	}

}
